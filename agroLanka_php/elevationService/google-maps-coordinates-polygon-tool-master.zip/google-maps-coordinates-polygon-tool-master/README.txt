A Pen created at CodePen.io. You can find this one at http://codepen.io/jhawes/pen/ujdgK.

 Outputs the coordinates (longitude, latitude) for Google Maps whenever the Polygon is moved or re-shaped. Recently added a 'Copy to Clipboard' button and had data output into a textarea for easier copying & pasting

I originally built this to build map outlines for neighborhoods, villages, districts and counties - specifically for real estate purposes.